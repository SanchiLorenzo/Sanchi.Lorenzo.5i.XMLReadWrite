﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace Sanchi.Lorenzo._5i.XMLReadWrite.Controllers
{
    public class ReadWriteController : Controller
    {
        private Persone P { get; set; }
        // GET: ReadWrite
        public ActionResult Index()
        {
            string nomeFile = HostingEnvironment.MapPath(@"~/App_Data/dati.xml");
            P = new Persone(nomeFile);
            P.Aggiungi();
            return View(P);
        }


        public ActionResult azione(string a)
        {
            return View(a);
        }
    }
}