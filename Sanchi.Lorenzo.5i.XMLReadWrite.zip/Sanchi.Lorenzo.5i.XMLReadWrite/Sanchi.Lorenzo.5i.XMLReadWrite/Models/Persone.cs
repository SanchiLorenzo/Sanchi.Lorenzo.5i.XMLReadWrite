﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace Sanchi.Lorenzo._5i.XMLReadWrite
{
    public class Persone : List<Persona>
    {
        public string NomeFile { get; }

        public XElement XML
        {
            get
            {
                return new XElement("Rubrica", from item in this select item.XML);
            }
        }

        public Persone(string nome)
        {
            NomeFile = nome;
            XElement Elements = XElement.Load(NomeFile);
            AddRange(
                from item in Elements.Elements("Persona")
                select new Persona(item)
            );
        }

        void Save()
        {
            XML.Save(NomeFile);
        }

        public void Aggiungi()
        {
            Add(
                new Persona
                {
                    Nome = "PersonaN",
                    Cognome = "CognomeN",
                    Telefono = "TelefonoN",
                    Indirizzo = "IndirizzoN"
                }
            );

            Save();
        }
    }
}