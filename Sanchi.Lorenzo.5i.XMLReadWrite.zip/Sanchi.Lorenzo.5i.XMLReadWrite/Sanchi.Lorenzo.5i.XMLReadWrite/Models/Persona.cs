﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace Sanchi.Lorenzo._5i.XMLReadWrite
{
    public class Persona
    {
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string Telefono { get; set; }
        public string Indirizzo { get; set; }

        public XElement XML
        {
            get
            {
                return new XElement("Persona",
                new XAttribute("Nome", Nome),
                new XAttribute("Cognome", Cognome),
                new XAttribute("Telefono", Telefono),
                new XAttribute("Indirizzo", Indirizzo)
                );
            }
        }

        public Persona(XElement elemento)
        {
            Nome = elemento.Attribute("Nome").Value;
            Cognome = elemento.Attribute("Cognome").Value;
            Telefono = elemento.Attribute("Telefono").Value;
            Indirizzo = elemento.Attribute("Indirizzo").Value;
        }

        public Persona(string nome, string cognome, string telefono, string indirizzo)
        {
            Nome = nome;
            Cognome = cognome;
            Telefono = telefono;
            Indirizzo = indirizzo;
        }

        public Persona()
        {

        }
    }


}