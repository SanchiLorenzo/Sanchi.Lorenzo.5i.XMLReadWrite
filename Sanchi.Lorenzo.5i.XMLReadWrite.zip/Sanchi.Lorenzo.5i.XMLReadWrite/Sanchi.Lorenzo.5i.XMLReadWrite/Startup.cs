﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Sanchi.Lorenzo._5i.XMLReadWrite.Startup))]
namespace Sanchi.Lorenzo._5i.XMLReadWrite
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
